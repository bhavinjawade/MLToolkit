var menu = {
    Input: {
        CSV: "pandas_abbrv"
        Chemical: "chemml.datasets"
    },
    Represent: {
        Dimensionality Reduction: "sklearn.decomposition"
        Chemical: "chemml.chem"
    },
    Prepare: {
        Preprocessing: "sklearn.preprocessing"
        Data Splitting: "chemml.wrapper.preprocessing_ui_prepare"
    },
    Model: {
        Linear: "sklearn.linear_model",
        Neural Network: "chemml.models",
        Support Vector Machines: "sklearn.svm"
    },
    Optimize: {
        Selection: "sklearn.model_selection"
    },
    Output: {
        Store Plot: ""
        Store Data: "chemml.wrapper.preprocessing"
    }
}