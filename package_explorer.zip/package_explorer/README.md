# package_explorer
Explore a python package with documentation in the numpy documentation format. Primarily meant for numpy and scipy.

Usage: `python pkg_inspect.py sklearn.decomposition`
