import sys
import json

def main(js):
    obj_input = {
        'name': 'obj',
        'docstring': 'True/False flag to indicate reusing the same instance instead of creating a new one',
        'param_type': [
            'bool'
        ],
        'expected_shape': None,
        'is_optional': True,
        'default_value': False,
        'options': None
    }
    obj_output = {
        'name': 'obj',
        'docstring': 'True/False flag to indicate reusing the same instance instead of creating a new one',
        'param_type': [
            'bool'
        ],
        'returned': True
    }
    for node_function in js['node_functions']:
        if node_function['name'][0] == '_':
            continue
        node_function['inputs'] += [obj_input]
        node_function['outputs'] += [obj_output]
    for node in js['nodes']:
        for node_function in node['node_functions']:
            if node_function['name'][0] == '_':
                continue
            node_function['inputs'] += [obj_input]
            node_function['outputs'] += [obj_output]

if __name__ == '__main__':
    fname = sys.argv[1]
    print(fname)
    with open(fname, 'r') as f:
        js = json.load(f)
    main(js)
    print('.'.join(fname.split('.')[:-1]) + '_ui.json')
    with open('.'.join(fname.split('.')[:-1]) + '_ui.json', 'w') as f:
        jsstr = json.dumps(js, indent=4, sort_keys=False)
        f.write(jsstr)



